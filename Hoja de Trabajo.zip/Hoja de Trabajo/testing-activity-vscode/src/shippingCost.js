/**
 * Cálculo de costo de envío según tabla de decisión (ver README).
 * amount: número (Q)
 * isPremium: boolean
 * isFragile: boolean
 * isInternational: boolean
 * Retorna costo numérico en quetzales.
 */
function computeShippingCost(amount, isPremium, isFragile, isInternational) {
  if (typeof amount !== 'number' || Number.isNaN(amount)) {
    throw new TypeError('amount debe ser numérico');
  }
  [isPremium, isFragile, isInternational].forEach((b) => {
    if (typeof b !== 'boolean') throw new TypeError('flags deben ser booleanos');
  });

  const base = isInternational ? 100 : 25;

  // Regla gratis para Premium con >=100 (siempre)
  if (isPremium && amount >= 100) return 0;

  // Regla gratis para Standard: local, no frágil, amount >= 200
  const isStandard = !isPremium;
  if (isStandard && !isInternational && !isFragile && amount >= 200) {
    return 0;
  }

  // No aplica gratis => cobra base + frágil si corresponde
  let cost = base;
  if (isFragile) cost += 15;
  return cost;
}

module.exports = { computeShippingCost };
