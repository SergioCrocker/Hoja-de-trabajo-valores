/**
 * Evaluación de solicitud de crédito
 * Reglas (ver README):
 * - Edad: 18–65 inclusive
 * - Ingreso: >= 1000
 * - Score: <600 REJECT, 600–749 REVIEW, >=750 APPROVE
 * - Si edad fuera de rango o ingreso < 1000 => REJECT directo
 */
function evaluateLoanApplicant(age, monthlyIncome, creditScore) {
  // Validaciones de tipo mínimas
  [age, monthlyIncome, creditScore].forEach((v) => {
    if (typeof v !== 'number' || Number.isNaN(v)) {
      throw new TypeError('Los parámetros deben ser numéricos.');
    }
  });

  // Reglas duras
  const ageOk = age >= 18 && age <= 65;
  const incomeOk = monthlyIncome >= 1000;
  if (!ageOk || !incomeOk) return 'REJECT';

  if (creditScore < 600) return 'REJECT';
  if (creditScore <= 749) return 'REVIEW';
  return 'APPROVE';
}

module.exports = { evaluateLoanApplicant };
