const { evaluateLoanApplicant } = require('../src/evaluateLoan');

describe('Equivalencia y Valores Frontera: evaluateLoanApplicant', () => {
  test('Tipo incorrecto lanza error', () => {
    expect(() => evaluateLoanApplicant('18', 1000, 750)).toThrow(TypeError);
  });

  // Edad (VF): 17 -> REJECT
  test('Edad 17 (fuera de rango) => REJECT', () => {
    expect(evaluateLoanApplicant(17, 2000, 800)).toBe('REJECT');
  });

  // Edad (VF): 18 -> mínimo válido
  test('Edad 18, ingreso 1000, score 750 => APPROVE', () => {
    expect(evaluateLoanApplicant(18, 1000, 750)).toBe('APPROVE');
  });

  // Edad (VF): 65 -> máximo válido
  test('Edad 65, ingreso 1000, score 750 => APPROVE', () => {
    expect(evaluateLoanApplicant(65, 1000, 750)).toBe('APPROVE');
  });

  // Edad (VF): 66 -> REJECT por edad
  test('Edad 66 => REJECT', () => {
    expect(evaluateLoanApplicant(66, 5000, 800)).toBe('REJECT');
  });

  // Ingreso (VF): 999 -> REJECT
  test('Ingreso 999 => REJECT', () => {
    expect(evaluateLoanApplicant(30, 999, 800)).toBe('REJECT');
  });

  // Ingreso (VF): 1000 -> válido
  test('Ingreso 1000 con score 599 => REJECT por score', () => {
    expect(evaluateLoanApplicant(30, 1000, 599)).toBe('REJECT');
  });

  // Score (VF): 600 -> REVIEW
  test('Score 600 => REVIEW', () => {
    expect(evaluateLoanApplicant(30, 5000, 600)).toBe('REVIEW');
  });

  // Score intermedio: 700 -> REVIEW
  test('Score 700 => REVIEW', () => {
    expect(evaluateLoanApplicant(30, 5000, 700)).toBe('REVIEW');
  });

  // Score (VF): 750 -> APPROVE
  test('Score 750 => APPROVE', () => {
    expect(evaluateLoanApplicant(30, 5000, 750)).toBe('APPROVE');
  });
});
