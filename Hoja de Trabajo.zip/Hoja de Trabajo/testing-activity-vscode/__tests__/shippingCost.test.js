const { computeShippingCost } = require('../src/shippingCost');

describe('Tablas de decisión: computeShippingCost', () => {
  test('Tipos inválidos', () => {
    expect(() => computeShippingCost('100', true, false, false)).toThrow(TypeError);
    expect(() => computeShippingCost(100, 'true', false, false)).toThrow(TypeError);
  });

  test('Premium con amount >=100 (local) => gratis', () => {
    expect(computeShippingCost(100, true, false, false)).toBe(0);
  });

  test('Premium con amount >=100 (internacional y frágil) => gratis (manda la regla premium)', () => {
    expect(computeShippingCost(150, true, true, true)).toBe(0);
  });

  test('Standard local, no frágil, amount >=200 => gratis', () => {
    expect(computeShippingCost(200, false, false, false)).toBe(0);
  });

  test('Standard local, frágil, amount >=200 => NO gratis (frágil anula) => base 25 + 15', () => {
    expect(computeShippingCost(250, false, true, false)).toBe(40);
  });

  test('Standard internacional, amount >=200 => NO gratis (internacional cobra) => base 100 (+ frágil si aplica)', () => {
    expect(computeShippingCost(300, false, false, true)).toBe(100);
    expect(computeShippingCost(300, false, true, true)).toBe(115);
  });

  test('Caso general local sin gratis: base 25, frágil suma 15', () => {
    expect(computeShippingCost(50, false, false, false)).toBe(25);
    expect(computeShippingCost(50, false, true, false)).toBe(40);
  });
});
