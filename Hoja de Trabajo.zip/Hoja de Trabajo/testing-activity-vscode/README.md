# Pruebas de Caja Negra en VS Code
**Clases de equivalencia**, **Análisis de valores frontera** y **Tablas de decisión** con código y pruebas unitarias (Jest).

## Requisitos
- Node.js 18+
- Visual Studio Code (VS Code)

## Instalación rápida
```bash
npm i
npm test
```
> Consejo: abre esta carpeta en VS Code (`testing-activity-vscode/`).

---

# 1) Clases de equivalencia y valores frontera
### Enunciado (caso práctico): Evaluación de solicitud de crédito
Implemente `evaluateLoanApplicant(age, monthlyIncome, creditScore)` que retorna:
- `"REJECT"` (rechazar)
- `"REVIEW"` (revisión manual)
- `"APPROVE"` (aprobar)

### Reglas de negocio
1. Edad mínima 18 años, máxima 65 años (inclusive).
2. Ingreso mensual mínimo: Q 1,000.
3. Puntaje de crédito:
   - < 600: **riesgo alto**
   - 600–749: **riesgo medio**
   - ≥ 750: **riesgo bajo**
4. Decisión:
   - Si edad fuera de rango **o** ingreso < 1000 ⇒ `REJECT`.
   - Si crédito < 600 ⇒ `REJECT`.
   - Si crédito 600–749 ⇒ `REVIEW`.
   - Si crédito ≥ 750 ⇒ `APPROVE`.

### Clases de equivalencia (CE) propuestas
**Edad**:  
- CE1: edad < 18 (inválida)  
- CE2: 18 ≤ edad ≤ 65 (válida)  
- CE3: edad > 65 (inválida)

**Ingreso**:  
- CE4: ingreso < 1000 (inválido)  
- CE5: ingreso ≥ 1000 (válido)

**Crédito**:  
- CE6: score < 600 (alto riesgo → rechazo)  
- CE7: 600 ≤ score ≤ 749 (medio → revisión)  
- CE8: score ≥ 750 (bajo → aprueba)

### Valores frontera (VF) claves
- Edad: 17, **18**, 19 … 64, **65**, 66  
- Ingreso: 999, **1000**, 1001  
- Crédito: 599, **600**, 601 … 749, **750**, 751

En el archivo `__tests__/evaluateLoan.test.js` se cubren CE y VF con casos mínimos pero representativos.

---

# 2) Tablas de decisión
### Enunciado (caso práctico): Cálculo de costo de envío
Implemente `computeShippingCost(amount, isPremium, isFragile, isInternational)`:
- Base local: Q 25
- Base internacional: Q 100
- Cliente **Premium** tiene **envío gratis** si `amount ≥ 100` (local o internacional).
- Cliente **Standard** tiene **envío gratis** solo si `amount ≥ 200` y **no es frágil** y **no es internacional**.
- Suplemento por **frágil**: Q 15 (aplica si no es gratis).
- IVA (12%) **no** se considera en este ejercicio para simplificar.

### Tabla de decisión (simplificada)
| Regla | amount ≥ 200 | amount ≥ 100 | isPremium | isInternational | isFragile | Resultado |
|------:|:------------:|:------------:|:---------:|:---------------:|:---------:|:---------:|
| R1    |  –           |  –           |  –        |       –         |    –      | Si no aplica gratis ⇒ base según destino + (frágil? 15:0) |
| R2    |      –       |      ✔       |    ✔      |       –         |    –      | **Gratis** (premium con ≥100) |
| R3    |      ✔       |      –       |    ✘      |       ✘         |    ✘      | **Gratis** (standard local ≥200 sin frágil) |
| R4    |      ✔       |      –       |    ✘      |       ✔         |    –      | **NO gratis** (internacional siempre cobra base) |
| R5    |      ✔       |      –       |    ✘      |       ✘         |    ✔      | **NO gratis** (frágil anula el gratis del standard) |

> La implementación prioriza la regla de **envío gratis de Premium con ≥100**. Para **Standard** solo hay gratis si el pedido es **local** y **no frágil** y **≥200**.

En `__tests__/shippingCost.test.js` se valida la lógica de la tabla y casos bordes.

---

## Estructura del proyecto
```
testing-activity-vscode/
├─ package.json
├─ README.md
├─ src/
│  ├─ evaluateLoan.js
│  └─ shippingCost.js
└─ __tests__/
   ├─ evaluateLoan.test.js
   └─ shippingCost.test.js
```

## Scripts útiles
- `npm test` → ejecuta Jest en modo una sola vez
- `npm run test:watch` → tests en watch mode
- `npm run cov` → reporte de cobertura

---

